package com.example.appjorge;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Fragment;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Switch;
import android.widget.Toast;

public class pg4 extends AppCompatActivity {
    Switch miswitch;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pg4);
        miswitch =(Switch) findViewById(R.id.switch1);
        miswitch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(view.getId()==R.id.switch1) {
                    if (miswitch.isChecked()) {
                        Toast.makeText(getApplicationContext(), "luz prendida", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(getApplicationContext(), "luz apagada", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
}
