package com.example.appjorge;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class pg3 extends AppCompatActivity {
   private Button mibuton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pg3);

        mibuton =(Button)findViewById(R.id.llave);
        mibuton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(),"puerta abierta", Toast.LENGTH_SHORT).show();
            }
        });



    }
}
